package com.user.detail.serviceimpl;

import org.springframework.stereotype.Service;

import com.user.detail.entity.User;
import com.user.detail.service.IUserService;

@Service
public class UserServiceImpl implements IUserService {

	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUser(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

}
