Quick Start
-----------

To build the XML-based example website, please right-click on the folder "Sitefiles" in the project view and choose "XSL Transformation".

Refresh the folder ".\ExampleSite\output" by reloading the project with the "Project" menu command "Reload Project." Then expand the contents of the folder and double-click on "introduction.html", which will bring up the first page of the example web-site and will let you navigate through all the remaining pages directly within XMLSpy or StyleVision.

The contents of the pages in the example website contains the documentation on how the XML-based example website works, and why building XML-based web sites is a smart idea...


Content Editing
---------------

To edit the content of the example website, open the folder "Sitefiles" and edit the XML files contained therein.